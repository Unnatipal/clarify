package com.clarify.doubts.web;

import com.clarify.doubts.model.Doubt;
import com.clarify.doubts.model.DoubtStatus;
import com.clarify.doubts.model.Reply;
import com.clarify.doubts.repo.DoubtRepository;
import com.clarify.doubts.repo.ReplyRepository;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/doubts")
public class DoubtController {
  private final DoubtRepository doubts;
  private final ReplyRepository replies;

  public DoubtController(DoubtRepository doubts, ReplyRepository replies) {
    this.doubts = doubts;
    this.replies = replies;
  }

  @GetMapping
  public List<Doubt> list() {
    return doubts.findAll();
  }

  @PostMapping
  public ResponseEntity<Doubt> create(@Valid @RequestBody Doubt body) {
    Doubt saved = doubts.save(body);
    return ResponseEntity.created(URI.create("/api/doubts/" + saved.getId())).body(saved);
  }

  @GetMapping("/{id}")
  public ResponseEntity<Doubt> get(@PathVariable Long id) {
    return doubts.findById(id).map(ResponseEntity::ok).orElseGet(() -> ResponseEntity.notFound().build());
  }

  @PatchMapping("/{id}/status")
  public ResponseEntity<Doubt> updateStatus(@PathVariable Long id, @RequestParam DoubtStatus status) {
    return doubts.findById(id).map(d -> {
      d.setStatus(status);
      return ResponseEntity.ok(doubts.save(d));
    }).orElseGet(() -> ResponseEntity.notFound().build());
  }

  @PostMapping("/{id}/replies")
  public ResponseEntity<Doubt> addReply(@PathVariable Long id, @Valid @RequestBody Reply body) {
    return doubts.findById(id).map(d -> {
      body.setDoubt(d);
      replies.save(body);
      return ResponseEntity.ok(doubts.findById(id).get());
    }).orElseGet(() -> ResponseEntity.notFound().build());
  }
}
