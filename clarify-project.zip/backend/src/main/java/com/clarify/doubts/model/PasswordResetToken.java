package com.clarify.doubts.model;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
public class PasswordResetToken {
  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Long id;
  @Column(nullable = false)
  private String email;
  @Column(nullable = false)
  private String token;
  @Column(nullable = false)
  private Instant expiresAt;
  private boolean used = false;
  public Long getId() { return id; }
  public void setId(Long id) { this.id = id; }
  public String getEmail() { return email; }
  public void setEmail(String email) { this.email = email; }
  public String getToken() { return token; }
  public void setToken(String token) { this.token = token; }
  public Instant getExpiresAt() { return expiresAt; }
  public void setExpiresAt(Instant expiresAt) { this.expiresAt = expiresAt; }
  public boolean isUsed() { return used; }
  public void setUsed(boolean used) { this.used = used; }
}
