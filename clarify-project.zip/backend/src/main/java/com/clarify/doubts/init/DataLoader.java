package com.clarify.doubts.init;

import com.clarify.doubts.model.Doubt;
import com.clarify.doubts.model.Reply;
import com.clarify.doubts.model.AppUser;
import com.clarify.doubts.repo.DoubtRepository;
import com.clarify.doubts.repo.ReplyRepository;
import com.clarify.doubts.repo.AppUserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class DataLoader {
  @Bean
  CommandLineRunner loadData(DoubtRepository doubts, ReplyRepository replies, AppUserRepository users) {
    return args -> {
      if (doubts.count() == 0) {
        Doubt d1 = new Doubt();
        d1.setTitle("How to fix NullPointerException?");
        d1.setDescription("I get NullPointerException when accessing a field. What is the approach to avoid it?");
        d1.setAuthorName("Alice");
        doubts.save(d1);
        Reply r1 = new Reply();
        r1.setDoubt(d1);
        r1.setAuthorName("Bob");
        r1.setMessage("Check for null before access or use Optional where appropriate.");
        replies.save(r1);
        Doubt d2 = new Doubt();
        d2.setTitle("Difference between List and Set?");
        d2.setDescription("What are the main differences and when to use each?");
        d2.setAuthorName("Charlie");
        doubts.save(d2);
      }
      if (!users.existsByUsername("user")) {
        AppUser u = new AppUser();
        u.setUsername("user");
        u.setPassword("password");
        u.setRoles("USER");
        users.save(u);
      }
      if (!users.existsByUsername("admin")) {
        AppUser a = new AppUser();
        a.setUsername("admin");
        a.setPassword("admin");
        a.setRoles("ADMIN");
        users.save(a);
      }
    };
  }
}
