const BASE_URL = 'http://localhost:8080/api'
let auth = { username: null, password: null }
export function setAuthCredentials(username, password) {
  auth = { username, password }
  try {
    localStorage.setItem('clarifyAuth', JSON.stringify(auth))
  } catch {}
}
export function loadStoredAuth() {
  try {
    const s = localStorage.getItem('clarifyAuth')
    if (s) auth = JSON.parse(s)
  } catch {}
}
export function getStoredAuth() {
  return auth
}
export function clearAuth() {
  auth = { username: null, password: null }
  try {
    localStorage.removeItem('clarifyAuth')
  } catch {}
}
function authHeaders() {
  if (auth.username && auth.password) {
    const token = btoa(`${auth.username}:${auth.password}`)
    return { Authorization: `Basic ${token}` }
  }
  return {}
}

export async function listDoubts() {
  const res = await fetch(`${BASE_URL}/doubts`)
  return res.json()
}

export async function createDoubt(d) {
  const res = await fetch(`${BASE_URL}/doubts`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...authHeaders() },
    body: JSON.stringify(d)
  })
  return res.json()
}

export async function getDoubt(id) {
  const res = await fetch(`${BASE_URL}/doubts/${id}`)
  return res.json()
}

export async function updateStatus(id, status) {
  const res = await fetch(`${BASE_URL}/doubts/${id}/status?status=${status}`, { method: 'PATCH', headers: authHeaders() })
  return res.json()
}

export async function addReply(id, r) {
  const res = await fetch(`${BASE_URL}/doubts/${id}/replies`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', ...authHeaders() },
    body: JSON.stringify(r)
  })
  return res.json()
}

export async function signup(username, password) {
  const res = await fetch(`http://localhost:8080/api/auth/signup`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password })
  })
  return res
}

export async function me() {
  const res = await fetch(`http://localhost:8080/api/auth/me`, { headers: { ...authHeaders() } })
  return res
}

export async function forgotPassword(email) {
  const res = await fetch(`http://localhost:8080/api/auth/forgot`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email })
  })
  return res.json()
}

export async function resetPassword(email, otp, password) {
  const res = await fetch(`http://localhost:8080/api/auth/reset`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, otp, password })
  })
  return res
}

export async function createPost({ content, file }) {
  const fd = new FormData()
  fd.append('content', content || '')
  if (file) fd.append('image', file)
  const res = await fetch(`http://localhost:8080/api/posts`, {
    method: 'POST',
    headers: { ...authHeaders() },
    body: fd
  })
  return res.json()
}

export async function getFeed({ following } = {}) {
  const res = await fetch(`http://localhost:8080/api/posts?following=${following ? 'true' : 'false'}`)
  return res.json()
}

export async function follow(username) {
  const res = await fetch(`http://localhost:8080/api/follow/${encodeURIComponent(username)}`, {
    method: 'POST',
    headers: { ...authHeaders() }
  })
  return res
}

export async function unfollow(username) {
  const res = await fetch(`http://localhost:8080/api/follow/${encodeURIComponent(username)}`, {
    method: 'DELETE',
    headers: { ...authHeaders() }
  })
  return res
}

export async function listFollowing() {
  const res = await fetch(`http://localhost:8080/api/follow/list`, { headers: { ...authHeaders() } })
  return res.json()
}
