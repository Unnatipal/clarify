import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { setAuthCredentials, me } from '../api'
import { required, isEmail, minLen } from '../validation'

export default function Login() {
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [showPass, setShowPass] = useState(false)
  const [remember, setRemember] = useState(true)
  const [errors, setErrors] = useState({})
  const [loading, setLoading] = useState(false)
  const navigate = useNavigate()
  const validate = () => {
    const e = {}
    if (!required(email) || !isEmail(email)) e.email = 'Enter a valid email'
    if (!minLen(password, 8)) e.password = 'Minimum 8 characters'
    setErrors(e)
    return Object.keys(e).length === 0
  }
  const submit = async (e) => {
    e.preventDefault()
    if (!validate()) return
    setLoading(true)
    try {
      setAuthCredentials(email, password)
      const res = await me()
      if (res.ok) {
        if (!remember) localStorage.removeItem('clarifyAuth')
        navigate('/app')
      } else {
        setErrors({ form: 'Invalid email or password' })
      }
    } catch {
      setErrors({ form: 'Server not reachable' })
    } finally {
      setLoading(false)
    }
  }
  return (
    <div className="container" style={{ maxWidth: 520 }}>
      <Link to="/" className="muted">← Back to Home</Link>
      <div className="card" style={{ marginTop: 16 }}>
        <h2>Welcome to <span className="accent">Clarify</span></h2>
        <p className="muted">Sign in to get your doubts resolved</p>
        <form className="form" onSubmit={submit}>
          <label>Email Address</label>
          <input className="input" type="email" placeholder="you@example.com" value={email} onChange={e => setEmail(e.target.value)} />
          {errors.email && <div className="error">{errors.email}</div>}
          <label>Password</label>
          <div style={{ display: 'flex', gap: 8 }}>
            <input className="input" style={{ flex: 1 }} placeholder="********" type={showPass ? 'text' : 'password'} value={password} onChange={e => setPassword(e.target.value)} />
            <button type="button" className="btn" onClick={() => setShowPass(x => !x)}>{showPass ? 'Hide' : 'Show'}</button>
          </div>
          {errors.password && <div className="error">{errors.password}</div>}
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <label style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
              <input type="checkbox" checked={remember} onChange={e => setRemember(e.target.checked)} /> Remember me
            </label>
            <Link to="/reset" className="muted">Forgot password?</Link>
          </div>
          {errors.form && <div className="error">{errors.form}</div>}
          <button className="btn primary" type="submit" disabled={loading}>{loading ? 'Signing In...' : 'Sign In'}</button>
          <div className="muted" style={{ textAlign: 'center' }}>Or continue with</div>
          <div style={{ display: 'flex', gap: 10 }}>
            <button className="btn" onClick={() => window.location.href = 'http://localhost:8080/oauth2/authorization/google'}>Google</button>
            <button className="btn" onClick={() => window.location.href = 'http://localhost:8080/oauth2/authorization/github'}>GitHub</button>
          </div>
          <div className="muted" style={{ textAlign: 'center' }}>
            Don’t have an account? <Link to="/signup">Sign up</Link>
          </div>
        </form>
      </div>
    </div>
  )
}
