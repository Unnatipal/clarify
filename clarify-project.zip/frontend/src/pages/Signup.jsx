
import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { signup } from '../api'
import { required, isEmail, minLen } from '../validation'

export default function Signup() {
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [confirm, setConfirm] = useState('')
  const [agree, setAgree] = useState(false)
  const [errors, setErrors] = useState({})
  const [loading, setLoading] = useState(false)
  const navigate = useNavigate()
  const validate = () => {
    const e = {}
    if (!required(name)) e.name = 'Full name is required'
    if (!required(email) || !isEmail(email)) e.email = 'Enter a valid email'
    if (!minLen(password, 8)) e.password = 'Minimum 8 characters'
    if (confirm !== password) e.confirm = 'Passwords do not match'
    if (!agree) e.agree = 'You must agree to Terms and Privacy Policy'
    setErrors(e)
    return Object.keys(e).length === 0
  }
  const submit = async (e) => {
    e.preventDefault()
    if (!validate()) return
    setLoading(true)
    try {
      const res = await signup(email, password)
      if (res.ok) {
        navigate('/login')
      } else {
        const t = await res.text()
        setErrors({ form: t || 'Signup failed' })
      }
    } catch {
      setErrors({ form: 'Server not reachable' })
    } finally {
      setLoading(false)
    }
  }
  return (
    <div className="container" style={{ maxWidth: 520 }}>
      <Link to="/" className="muted">← Back to Home</Link>
      <div className="card" style={{ marginTop: 16 }}>
        <h2>Join <span className="accent">Clarify</span></h2>
        <p className="muted">Create your account and start learning</p>
        <form className="form" onSubmit={submit}>
          <label>Full Name</label>
          <input className="input" placeholder="John Doe" value={name} onChange={e => setName(e.target.value)} />
          {errors.name && <div className="error">{errors.name}</div>}
          <label>Email Address</label>
          <input className="input" type="email" placeholder="you@example.com" value={email} onChange={e => setEmail(e.target.value)} />
          {errors.email && <div className="error">{errors.email}</div>}
          <label>Password</label>
          <input className="input" type="password" placeholder="********" value={password} onChange={e => setPassword(e.target.value)} />
          {errors.password && <div className="error">{errors.password}</div>}
          <label>Confirm Password</label>
          <input className="input" type="password" placeholder="********" value={confirm} onChange={e => setConfirm(e.target.value)} />
          {errors.confirm && <div className="error">{errors.confirm}</div>}
          <label style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
            <input type="checkbox" checked={agree} onChange={e => setAgree(e.target.checked)} /> I agree to the <Link to="/terms">Terms of Service</Link> and <Link to="/privacy">Privacy Policy</Link>
          </label>
          {errors.agree && <div className="error">{errors.agree}</div>}
          {errors.form && <div className="error">{errors.form}</div>}
          <button className="btn primary" type="submit" disabled={loading}>{loading ? 'Creating...' : 'Create Account'}</button>
          <div className="muted" style={{ textAlign: 'center' }}>
            Already have an account? <Link to="/login">Log In</Link>
          </div>
        </form>
      </div>
    </div>
  )
}
