import React, { useEffect, useState } from 'react'
import { BrowserRouter, Routes, Route, useNavigate, useParams, Link } from 'react-router-dom'
import { listDoubts, createDoubt, getDoubt, addReply, updateStatus, setAuthCredentials, loadStoredAuth, createPost, getFeed, getStoredAuth, clearAuth } from './api'
import Home from './pages/Home'
import Login from './pages/Login'
import Signup from './pages/Signup'
import Reset from './pages/Reset'

function DoubtList({ doubts, onSelect }) {
  return (
    <div>
      <h2>Doubts</h2>
      <ul>
        {doubts.map(d => (
          <li key={d.id} style={{ marginBottom: 8 }}>
            <button onClick={() => onSelect(d.id)}>{d.title}</button>
            <span style={{ marginLeft: 8 }}>by {d.authorName}</span>
            <span style={{ marginLeft: 8 }}>{d.status}</span>
          </li>
        ))}
      </ul>
    </div>
  )
}

function DoubtForm({ onCreate }) {
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [authorName, setAuthorName] = useState('')
  return (
    <div>
      <h2>Ask Doubt</h2>
      <input placeholder="Title" value={title} onChange={e => setTitle(e.target.value)} />
      <br />
      <input placeholder="Your name" value={authorName} onChange={e => setAuthorName(e.target.value)} />
      <br />
      <textarea placeholder="Description" value={description} onChange={e => setDescription(e.target.value)} />
      <br />
      <button onClick={() => onCreate({ title, description, authorName })}>Submit</button>
    </div>
  )
}

function ReplyForm({ onReply }) {
  const [authorName, setAuthorName] = useState('')
  const [message, setMessage] = useState('')
  return (
    <div>
      <h3>Add Reply</h3>
      <input placeholder="Your name" value={authorName} onChange={e => setAuthorName(e.target.value)} />
      <br />
      <textarea placeholder="Message" value={message} onChange={e => setMessage(e.target.value)} />
      <br />
      <button onClick={() => onReply({ authorName, message })}>Reply</button>
    </div>
  )
}

function DoubtDetail({ onRefresh }) {
  const { id } = useParams()
  const [doubt, setDoubt] = useState(null)
  useEffect(() => {
    getDoubt(id).then(setDoubt)
  }, [id])
  if (!doubt) return <div>Loading...</div>
  return (
    <div>
      <Link to="/">Back</Link>
      <h2>{doubt.title}</h2>
      <div>by {doubt.authorName}</div>
      <div>{doubt.description}</div>
      <div>Status: {doubt.status}</div>
      <button onClick={async () => { await updateStatus(id, doubt.status === 'OPEN' ? 'SOLVED' : 'OPEN'); const d = await getDoubt(id); setDoubt(d); onRefresh(); }}>Toggle Status</button>
      <h3>Replies</h3>
      <ul>
        {(doubt.replies || []).map(r => (
          <li key={r.id}>
            <div>{r.message}</div>
            <div>by {r.authorName}</div>
          </li>
        ))}
      </ul>
      <ReplyForm onReply={async r => { await addReply(id, r); const d = await getDoubt(id); setDoubt(d); onRefresh(); }} />
    </div>
  )
}

function LoginBar() {
  const [u, setU] = useState('')
  const [p, setP] = useState('')
  return (
    <div style={{ marginBottom: 16 }}>
      <input placeholder="Username" value={u} onChange={e => setU(e.target.value)} />
      <input placeholder="Password" type="password" value={p} onChange={e => setP(e.target.value)} />
      <button onClick={() => setAuthCredentials(u, p)}>Set Auth</button>
      <span style={{ marginLeft: 8 }}>Use user/password or admin/admin</span>
    </div>
  )
}


function Nav() {
  const auth = getStoredAuth()
  const [open, setOpen] = useState(false)
  return (
    <nav className="nav">
      <div className="nav-left">
        <Link to="/" className="brand"><div className="badge">C</div> Clarify</Link>
        <input className="search" placeholder="Search for doubts..." onKeyDown={e => { if (e.key === 'Enter') window.location.href='/app' }} />
      </div>
      <div className="nav-right">
        <Link to="/app" className="btn">Home</Link>
        <Link to="/app" className="btn primary">Ask Doubt</Link>
        {auth.username ? (
          <>
            <button className="icon-btn">🔔</button>
            <div className="dropdown">
              <button className="avatar-sm" onClick={() => setOpen(x => !x)}>{auth.username.slice(0,1).toUpperCase()}</button>
              {open && (
                <div className="dropdown-menu">
                  <div className="dropdown-item"><span>Account</span><span>{auth.username}</span></div>
                  <div className="dropdown-item"><span>Notifications</span><span>0</span></div>
                  <div className="dropdown-item"><button className="btn" onClick={() => { clearAuth(); window.location.href='/'; }}>Logout</button></div>
                </div>
              )}
            </div>
          </>
        ) : (
          <>
            <Link to="/login" className="btn">Log In</Link>
            <Link to="/signup" className="btn primary">Sign Up</Link>
          </>
        )}
      </div>
    </nav>
  )
}

function DoubtApp() {
  const [doubts, setDoubts] = useState([])
  const [posts, setPosts] = useState([])
  const [content, setContent] = useState('')
  const [file, setFile] = useState(null)
  const [followingOnly, setFollowingOnly] = useState(false)
  const [filter, setFilter] = useState('ALL')
  const navigate = useNavigate()
  const refreshDoubts = () => listDoubts().then(setDoubts)
  const refreshFeed = () => getFeed({ following: followingOnly }).then(setPosts)
  useEffect(() => { refreshDoubts() }, [])
  useEffect(() => { refreshFeed() }, [followingOnly])
  const submitPost = async () => {
    if (!content && !file) return
    await createPost({ content, file })
    setContent(''); setFile(null)
    refreshFeed()
  }
  return (
    <div className="container">
      <div className="stats">
        <div className="stat-card"><div style={{fontSize:28,fontWeight:700}}>Clarify</div><div className="muted">Experience collaborative learning</div></div>
        <div className="stat-card"><div style={{fontSize:28,fontWeight:700}}>{doubts.length}</div><div className="muted">Questions</div></div>
        <div className="stat-card"><div style={{fontSize:28,fontWeight:700}}>{doubts.filter(d=>d.status==='SOLVED').length}</div><div className="muted">Solved</div></div>
      </div>
      <div className="feed">
        <div>
          <div className="card composer">
            <div className="row">
              <div className="avatar">C</div>
              <input className="input" placeholder="Share a fact, tip, or doubt..." value={content} onChange={e => setContent(e.target.value)} />
              <input type="file" onChange={e => setFile(e.target.files[0])} />
              <button className="btn primary" onClick={submitPost}>Post</button>
            </div>
          </div>
          {posts.map(p => (
            <div key={p.id} className="card post">
              <div className="post-header">
                <div className="avatar">{(p.authorUsername||'U').slice(0,1).toUpperCase()}</div>
                <div>
                  <strong>{p.authorUsername}</strong>
                  <div className="muted">{new Date(p.createdAt).toLocaleString()}</div>
                </div>
              </div>
              {p.content && <div>{p.content}</div>}
              {p.imageUrl && <img className="post-img" src={`http://localhost:8080${p.imageUrl}`} alt="" />}
            </div>
          ))}
        </div>
        <div>
          <div className="card">
            <strong>Ask Your Doubt</strong>
            <DoubtForm onCreate={async d => { await createDoubt(d); refreshDoubts() }} />
          </div>
          <div className="card">
            <div style={{display:'flex',justifyContent:'space-between',alignItems:'center'}}>
              <strong>Recent Doubts</strong>
              <div style={{display:'flex',gap:8}}>
                <button className="btn" onClick={()=>setFilter('ALL')}>All</button>
                <button className="btn" onClick={()=>setFilter('OPEN')}>Open</button>
                <button className="btn" onClick={()=>setFilter('SOLVED')}>Answered</button>
              </div>
            </div>
            <DoubtList doubts={doubts.filter(d=>filter==='ALL'?true:d.status===filter)} onSelect={id => navigate(`/doubt/${id}`)} />
          </div>
          <div className="card">
            <strong>Trending Topics</strong>
            <div><span className="badge-pill">React</span><span className="badge-pill">JavaScript</span><span className="badge-pill">Algorithms</span></div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default function App() {
  loadStoredAuth()
  return (
    <BrowserRouter>
      <Nav />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/reset" element={<Reset />} />
        <Route path="/app" element={<DoubtApp />} />
        <Route path="/doubt/:id" element={<DoubtDetail onRefresh={() => {}} />} />
      </Routes>
    </BrowserRouter>
  )
}
